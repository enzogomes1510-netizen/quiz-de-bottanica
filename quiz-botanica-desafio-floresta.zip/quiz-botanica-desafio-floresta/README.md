# Quiz de Botânica — Desafio da Floresta

## Alterações
- Fundo atualizado para uma imagem de floresta.
- Identidade visual e textos atualizados para “Desafio da Floresta”.
- Adicionado menu Multiplayer com criação de sala, código, nome e avatar emoji.
- As perguntas e o modo solo original foram mantidos.

## Importante sobre o multiplayer
Esta versão inclui um **protótipo local**: salas ficam guardadas no `localStorage` do navegador. Isso permite testar a interface, mas **não sincroniza salas entre computadores ou celulares diferentes**. Para multiplayer real em tempo real, é necessário conectar um serviço de banco de dados em tempo real (por exemplo, Firebase Realtime Database) e configurar as credenciais do projeto.

## Publicar no GitHub Pages
Substitua o `index.html` do repositório pelo arquivo desta pasta e envie também os arquivos existentes do projeto. O fundo de floresta usa uma imagem hospedada externamente, portanto precisa de conexão com a internet para carregar.
